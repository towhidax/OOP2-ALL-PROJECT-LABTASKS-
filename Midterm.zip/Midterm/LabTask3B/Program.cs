﻿using System;


class Employee
{
    public int ID;
    public string Name;

    public Employee(int id, string name)
    {
        ID = id;
        Name = name;

        Console.WriteLine("Parent Constructor Executed");
        Console.WriteLine("Employee ID: " + ID);
        Console.WriteLine("Employee Name: " + Name);
    }
}


class PermanentEmployee : Employee
{
    public double Basic_Salary;
    public double Bonus;

    public PermanentEmployee(int id, string name, double basic, double bonus) : base(id, name)
    {
        Basic_Salary = basic;
        Bonus = bonus;

        Console.WriteLine("Child Constructor Executed");

        
        double totalSalary = Basic_Salary + Bonus;
        Console.WriteLine("Total Salary: " + totalSalary);
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("Creating Employee Object");

        PermanentEmployee emp = new PermanentEmployee(101, "Rahim", 25000, 5000);

        Console.WriteLine("Program Finished.");
    }
}