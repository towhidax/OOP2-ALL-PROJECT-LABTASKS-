using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurfLagbe
{
    public partial class MyBookingsForm : Form
    {
        public MyBookingsForm()
        {
            InitializeComponent();
        }

        private void MyBookingsForm_Load(object sender, EventArgs e)
        {
            LoadBookings();
            this.Activated += (s, args) => LoadBookings();
        }

        private void LoadBookings()
        {
            SqlConnection connection
                = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string query = "SELECT b.BookingId, "
                + "t.TurfName AS [Turf], "
                + "s.SlotName AS [Slot], "
                + "CONVERT(VARCHAR(5), s.StartTime, 108) + ' - ' + "
                + "CONVERT(VARCHAR(5), s.EndTime, 108) AS [Time], "
                + "CONVERT(VARCHAR(10), b.BookingDate, 120) AS [Date], "
                + "b.TotalAmount AS [Amount], "
                + "b.BookingStatus AS [Status] "
                + "FROM Bookings b "
                + "JOIN Turfs t ON b.TurfId = t.TurfId "
                + "JOIN Slots s ON b.SlotId = s.SlotId "
                + "WHERE b.UserId = @userId "
                + "ORDER BY b.BookingDate DESC, s.StartTime DESC";

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@userId", Session.UserId);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            bookingsGridView.DataSource = dataTable;

            connection.Close();

            if (bookingsGridView.Columns.Contains("BookingId"))
                bookingsGridView.Columns["BookingId"].Visible = false;

            if (bookingsGridView.Columns.Contains("Amount"))
                bookingsGridView.Columns["Amount"].DefaultCellStyle.Format = "N0";
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            if (bookingsGridView.SelectedRows.Count == 0)
            {
                lblStatus.Text = "Select a booking to cancel.";
                lblStatus.ForeColor = Color.FromArgb(211, 47, 47);
                return;
            }

            DataGridViewRow row = bookingsGridView.SelectedRows[0];
            string status = row.Cells["Status"].Value.ToString();

            if (status == "Cancelled")
            {
                lblStatus.Text = "This booking is already cancelled.";
                lblStatus.ForeColor = Color.FromArgb(211, 47, 47);
                return;
            }

            int bookingId = Convert.ToInt32(row.Cells["BookingId"].Value);

            DialogResult confirm = MessageBox.Show(
                "Are you sure you want to cancel this booking?",
                "Cancel Booking",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirm != DialogResult.Yes)
                return;

            SqlConnection connection
                = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            SqlCommand cmd1 = new SqlCommand(
                "UPDATE Bookings SET BookingStatus = 'Cancelled' "
                + "WHERE BookingId = @id", connection);
            cmd1.Parameters.AddWithValue("@id", bookingId);
            cmd1.ExecuteNonQuery();

            SqlCommand cmd2 = new SqlCommand(
                "UPDATE Payments SET Status = 'Refunded' "
                + "WHERE BookingId = @id", connection);
            cmd2.Parameters.AddWithValue("@id", bookingId);
            cmd2.ExecuteNonQuery();

            connection.Close();

            lblStatus.Text = "✓ Booking cancelled.";
            lblStatus.ForeColor = Color.FromArgb(46, 125, 50);
            LoadBookings();
        }
    }
}
