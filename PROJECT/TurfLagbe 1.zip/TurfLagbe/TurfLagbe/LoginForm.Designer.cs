namespace TurfLagbe
{
    partial class LoginForm
    {

        private System.ComponentModel.IContainer components = null;


        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelLogin = new Panel();
            lblError = new Label();
            loginButton = new Button();
            passwordTextBox = new TextBox();
            lblPassword = new Label();
            emailTextBox = new TextBox();
            lblEmail = new Label();
            lblTagline = new Label();
            lblLogo = new Label();
            panelLogin.SuspendLayout();
            SuspendLayout();
            // 
            // panelLogin
            // 
            panelLogin.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            panelLogin.BackColor = Color.FromArgb(30, 30, 30);
            panelLogin.Controls.Add(lblError);
            panelLogin.Controls.Add(loginButton);
            panelLogin.Controls.Add(passwordTextBox);
            panelLogin.Controls.Add(lblPassword);
            panelLogin.Controls.Add(emailTextBox);
            panelLogin.Controls.Add(lblEmail);
            panelLogin.Controls.Add(lblTagline);
            panelLogin.Controls.Add(lblLogo);
            panelLogin.Location = new Point(520, 0);
            panelLogin.Name = "panelLogin";
            panelLogin.Size = new Size(380, 500);
            // 
            // lblLogo
            // 
            lblLogo.Font = new Font("Segoe UI", 26F, FontStyle.Bold);
            lblLogo.ForeColor = Color.White;
            lblLogo.Location = new Point(35, 60);
            lblLogo.Name = "lblLogo";
            lblLogo.Size = new Size(310, 50);
            lblLogo.Text = "⚽ Turf Lagbe";
            // 
            // lblTagline
            // 
            lblTagline.Font = new Font("Segoe UI", 10F);
            lblTagline.ForeColor = Color.FromArgb(160, 160, 160);
            lblTagline.Location = new Point(38, 115);
            lblTagline.Name = "lblTagline";
            lblTagline.Size = new Size(310, 25);
            lblTagline.Text = "Book your turf. Play your game.";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblEmail.ForeColor = Color.FromArgb(200, 200, 200);
            lblEmail.Location = new Point(38, 175);
            lblEmail.Name = "lblEmail";
            lblEmail.Text = "Email *:";
            // 
            // emailTextBox
            // 
            emailTextBox.BackColor = Color.FromArgb(50, 50, 50);
            emailTextBox.BorderStyle = BorderStyle.FixedSingle;
            emailTextBox.Font = new Font("Segoe UI", 12F);
            emailTextBox.ForeColor = Color.White;
            emailTextBox.Location = new Point(38, 200);
            emailTextBox.Name = "emailTextBox";
            emailTextBox.Size = new Size(305, 34);
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblPassword.ForeColor = Color.FromArgb(200, 200, 200);
            lblPassword.Location = new Point(38, 255);
            lblPassword.Name = "lblPassword";
            lblPassword.Text = "Password *:";
            // 
            // passwordTextBox
            // 
            passwordTextBox.BackColor = Color.FromArgb(50, 50, 50);
            passwordTextBox.BorderStyle = BorderStyle.FixedSingle;
            passwordTextBox.Font = new Font("Segoe UI", 12F);
            passwordTextBox.ForeColor = Color.White;
            passwordTextBox.Location = new Point(38, 280);
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.PasswordChar = '*';
            passwordTextBox.Size = new Size(305, 34);
            // 
            // loginButton
            // 
            loginButton.BackColor = Color.FromArgb(46, 125, 50);
            loginButton.Cursor = Cursors.Hand;
            loginButton.FlatAppearance.BorderSize = 0;
            loginButton.FlatStyle = FlatStyle.Flat;
            loginButton.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            loginButton.ForeColor = Color.White;
            loginButton.Location = new Point(38, 345);
            loginButton.Name = "loginButton";
            loginButton.Size = new Size(305, 48);
            loginButton.Text = "Login";
            loginButton.Click += loginButton_Click;
            // 
            // lblError
            // 
            lblError.Font = new Font("Segoe UI", 9F);
            lblError.ForeColor = Color.FromArgb(239, 83, 80);
            lblError.Location = new Point(38, 400);
            lblError.Name = "lblError";
            lblError.Size = new Size(305, 25);
            lblError.Text = "";
            // 
            // LoginForm
            // 
            AcceptButton = loginButton;
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(900, 500);
            Controls.Add(panelLogin);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "LoginForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Turf Lagbe — Login";
            panelLogin.ResumeLayout(false);
            panelLogin.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelLogin;
        private Label lblLogo;
        private Label lblTagline;
        private Label lblEmail;
        private TextBox emailTextBox;
        private Label lblPassword;
        private TextBox passwordTextBox;
        private Button loginButton;
        private Label lblError;
    }
}
