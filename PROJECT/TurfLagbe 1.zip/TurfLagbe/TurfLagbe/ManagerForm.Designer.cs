namespace TurfLagbe
{
    partial class ManagerForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            panelHeader = new Panel();
            btnLogout = new Button();
            lblTitle = new Label();
            lblTurfInfo = new Label();
            lblFilter = new Label();
            cboFilter = new ComboBox();
            managerGridView = new DataGridView();
            lblRevenue = new Label();

            panelHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)managerGridView).BeginInit();
            SuspendLayout();
            //
            // panelHeader
            //
            panelHeader.BackColor = Color.FromArgb(27, 58, 38);
            panelHeader.Controls.Add(btnLogout);
            panelHeader.Controls.Add(lblTurfInfo);
            panelHeader.Controls.Add(lblTitle);
            panelHeader.Dock = DockStyle.Top;
            panelHeader.Size = new Size(950, 55);
            //
            // lblTitle
            //
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(18, 10);
            lblTitle.Text = "⚽ Turf Manager";
            //
            // lblTurfInfo
            //
            lblTurfInfo.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblTurfInfo.AutoSize = true;
            lblTurfInfo.Font = new Font("Segoe UI", 10F);
            lblTurfInfo.ForeColor = Color.FromArgb(160, 210, 180);
            lblTurfInfo.Location = new Point(550, 18);
            lblTurfInfo.Text = "";
            //
            // btnLogout
            //
            btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLogout.BackColor = Color.FromArgb(183, 28, 28);
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.FlatStyle = FlatStyle.Flat;
            btnLogout.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnLogout.ForeColor = Color.White;
            btnLogout.Location = new Point(840, 12);
            btnLogout.Size = new Size(85, 33);
            btnLogout.Text = "Logout";
            btnLogout.Cursor = Cursors.Hand;
            btnLogout.Click += btnLogout_Click;
            //
            // lblFilter
            //
            lblFilter.AutoSize = true;
            lblFilter.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblFilter.Location = new Point(20, 70);
            lblFilter.Text = "Filter:";
            //
            // cboFilter
            //
            cboFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFilter.Font = new Font("Segoe UI", 10F);
            cboFilter.Items.AddRange(new object[] { "All", "Pending", "Confirmed", "Cancelled" });
            cboFilter.Location = new Point(80, 67);
            cboFilter.Size = new Size(150, 31);
            cboFilter.SelectedIndexChanged += cboFilter_SelectedIndexChanged;
            //
            // managerGridView
            //
            managerGridView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            managerGridView.AllowUserToAddRows = false;
            managerGridView.AllowUserToDeleteRows = false;
            managerGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            managerGridView.BackgroundColor = Color.White;
            managerGridView.BorderStyle = BorderStyle.None;
            managerGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(27, 58, 38);
            managerGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            managerGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            managerGridView.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(27, 58, 38);
            managerGridView.ColumnHeadersHeight = 38;
            managerGridView.DefaultCellStyle.Font = new Font("Segoe UI", 10F);
            managerGridView.DefaultCellStyle.SelectionBackColor = Color.FromArgb(200, 230, 201);
            managerGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            managerGridView.EnableHeadersVisualStyles = false;
            managerGridView.GridColor = Color.FromArgb(224, 224, 224);
            managerGridView.Location = new Point(20, 110);
            managerGridView.MultiSelect = false;
            managerGridView.ReadOnly = true;
            managerGridView.RowHeadersVisible = false;
            managerGridView.RowTemplate.Height = 34;
            managerGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            managerGridView.Size = new Size(910, 380);
            //
            // lblRevenue
            //
            lblRevenue.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            lblRevenue.AutoSize = true;
            lblRevenue.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblRevenue.ForeColor = Color.FromArgb(46, 125, 50);
            lblRevenue.Location = new Point(20, 505);
            lblRevenue.Text = "";
            //
            // ManagerForm
            //
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(245, 245, 245);
            ClientSize = new Size(950, 545);
            Controls.Add(lblRevenue);
            Controls.Add(managerGridView);
            Controls.Add(cboFilter);
            Controls.Add(lblFilter);
            Controls.Add(panelHeader);
            MinimumSize = new Size(700, 400);
            Name = "ManagerForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Turf Lagbe — Manager";
            Load += ManagerForm_Load;
            panelHeader.ResumeLayout(false);
            panelHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)managerGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panelHeader;
        private Label lblTitle;
        private Label lblTurfInfo;
        private Button btnLogout;
        private Label lblFilter;
        private ComboBox cboFilter;
        private DataGridView managerGridView;
        private Label lblRevenue;
    }
}
