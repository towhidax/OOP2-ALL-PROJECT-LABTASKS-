using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurfLagbe
{
    public partial class AdminForm : Form
    {
        private int selectedTurfId = -1;
        private int selectedSlotId = -1;

        public AdminForm()
        {
            InitializeComponent();
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            cboFilter.SelectedIndex = 0;
            LoadAllBookings();
            LoadTurfsGrid();
            LoadTurfComboBox();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private void cboFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadAllBookings();
        }

        private void LoadAllBookings()
        {
            SqlConnection connection = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string filter = cboFilter.SelectedItem.ToString();
            string where = (filter == "All") ? "" : "WHERE b.BookingStatus = @status";

            string query = "SELECT b.BookingId AS [#], "
                + "u.FullName AS [User], t.TurfName AS [Turf], "
                + "s.SlotName AS [Slot], "
                + "CONVERT(VARCHAR(5), s.StartTime, 108) + ' - ' + "
                + "CONVERT(VARCHAR(5), s.EndTime, 108) AS [Time], "
                + "CONVERT(VARCHAR(10), b.BookingDate, 120) AS [Date], "
                + "b.TotalAmount AS [Amount], b.BookingStatus AS [Status], "
                + "ISNULL(p.PaymentMethod, '-') AS [Payment], "
                + "ISNULL(p.Status, '-') AS [Pay Status] "
                + "FROM Bookings b "
                + "JOIN Users u ON b.UserId = u.UserId "
                + "JOIN Turfs t ON b.TurfId = t.TurfId "
                + "JOIN Slots s ON b.SlotId = s.SlotId "
                + "LEFT JOIN Payments p ON b.BookingId = p.BookingId "
                + where + " ORDER BY b.BookingDate DESC";

            SqlCommand cmd = new SqlCommand(query, connection);
            if (filter != "All")
                cmd.Parameters.AddWithValue("@status", filter);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            allBookingsGridView.DataSource = dt;

            if (allBookingsGridView.Columns.Contains("Amount"))
                allBookingsGridView.Columns["Amount"].DefaultCellStyle.Format = "N0";

            string sumQuery = "SELECT COUNT(*), "
                + "SUM(CASE WHEN BookingStatus='Confirmed' THEN TotalAmount ELSE 0 END) "
                + "FROM Bookings";
            SqlCommand cmd2 = new SqlCommand(sumQuery, connection);
            SqlDataReader reader = cmd2.ExecuteReader();
            if (reader.Read())
            {
                int total = reader.GetInt32(0);
                decimal revenue = reader.IsDBNull(1) ? 0 : reader.GetDecimal(1);
                lblSummary.Text = $"Total Bookings: {total}   |   Confirmed Revenue: ৳{revenue:N0}";
            }
            reader.Close();
            connection.Close();
        }



        private void LoadTurfsGrid()
        {
            SqlConnection connection = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT TurfId, TurfName, Area, Address, FieldType, Capacity, Phone, Status "
                + "FROM Turfs ORDER BY TurfId", connection);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            turfsGridView.DataSource = dt;

            if (turfsGridView.Columns.Contains("TurfId"))
                turfsGridView.Columns["TurfId"].Visible = false;

            connection.Close();
        }

        private void turfsGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            DataGridViewRow row = turfsGridView.Rows[e.RowIndex];
            selectedTurfId = Convert.ToInt32(row.Cells["TurfId"].Value);
            txtTurfName.Text = row.Cells["TurfName"].Value.ToString();
            txtArea.Text = row.Cells["Area"].Value?.ToString() ?? "";
            txtAddress.Text = row.Cells["Address"].Value?.ToString() ?? "";
            string ft = row.Cells["FieldType"].Value?.ToString() ?? "Indoor";
            cboFieldType.SelectedItem = ft;
            txtCapacity.Text = row.Cells["Capacity"].Value?.ToString() ?? "";
            txtPhone.Text = row.Cells["Phone"].Value?.ToString() ?? "";
        }

        private void btnAddTurf_Click(object sender, EventArgs e)
        {
            if (txtTurfName.Text == string.Empty)
            {
                MessageBox.Show("Turf Name is required.");
                return;
            }

            SqlConnection connection = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string query = "INSERT INTO Turfs (TurfName, Area, Address, FieldType, Capacity, Phone) "
                + "VALUES (@name, @area, @address, @fieldType, @capacity, @phone)";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@name", txtTurfName.Text.Trim());
            cmd.Parameters.AddWithValue("@area", txtArea.Text.Trim());
            cmd.Parameters.AddWithValue("@address", txtAddress.Text.Trim());
            cmd.Parameters.AddWithValue("@fieldType", cboFieldType.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@capacity", txtCapacity.Text.Trim());
            cmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
            cmd.ExecuteNonQuery();
            connection.Close();

            MessageBox.Show("Turf added successfully!");
            ClearTurfFields();
            LoadTurfsGrid();
            LoadTurfComboBox();
        }

        private void btnUpdateTurf_Click(object sender, EventArgs e)
        {
            if (selectedTurfId == -1)
            {
                MessageBox.Show("Select a turf from the grid first.");
                return;
            }

            SqlConnection connection = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string query = "UPDATE Turfs SET TurfName=@name, Area=@area, Address=@address, "
                + "FieldType=@fieldType, Capacity=@capacity, Phone=@phone "
                + "WHERE TurfId=@id";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@name", txtTurfName.Text.Trim());
            cmd.Parameters.AddWithValue("@area", txtArea.Text.Trim());
            cmd.Parameters.AddWithValue("@address", txtAddress.Text.Trim());
            cmd.Parameters.AddWithValue("@fieldType", cboFieldType.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@capacity", txtCapacity.Text.Trim());
            cmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
            cmd.Parameters.AddWithValue("@id", selectedTurfId);
            cmd.ExecuteNonQuery();
            connection.Close();

            MessageBox.Show("Turf updated successfully!");
            ClearTurfFields();
            LoadTurfsGrid();
            LoadTurfComboBox();
        }

        private void ClearTurfFields()
        {
            selectedTurfId = -1;
            txtTurfName.Clear(); txtArea.Clear(); txtAddress.Clear();
            cboFieldType.SelectedIndex = 0; txtCapacity.Clear(); txtPhone.Clear();
        }



        private void LoadTurfComboBox()
        {
            SqlConnection connection = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            SqlCommand cmd = new SqlCommand(
                "SELECT TurfId, TurfName FROM Turfs WHERE Status='Active'", connection);
            SqlDataReader reader = cmd.ExecuteReader();

            cboTurf.Items.Clear();
            cboTurf.Items.Add("-- Select --");
            while (reader.Read())
            {
                cboTurf.Items.Add(new TurfItem(reader.GetInt32(0), reader.GetString(1)));
            }
            cboTurf.SelectedIndex = 0;

            reader.Close();
            connection.Close();
        }

        private void cboTurf_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboTurf.SelectedItem is TurfItem item)
            {
                LoadSlotsGrid(item.Id);
            }
        }

        private void LoadSlotsGrid(int turfId)
        {
            SqlConnection connection = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string query = "SELECT SlotId, SlotName, "
                + "CONVERT(VARCHAR(5), StartTime, 108) AS StartTime, "
                + "CONVERT(VARCHAR(5), EndTime, 108) AS EndTime, "
                + "PriceBDT, IsActive "
                + "FROM Slots WHERE TurfId=@turfId ORDER BY StartTime";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@turfId", turfId);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            slotsGridView.DataSource = dt;

            if (slotsGridView.Columns.Contains("SlotId"))
                slotsGridView.Columns["SlotId"].Visible = false;

            if (slotsGridView.Columns.Contains("PriceBDT"))
            {
                slotsGridView.Columns["PriceBDT"].HeaderText = "Price (৳)";
                slotsGridView.Columns["PriceBDT"].DefaultCellStyle.Format = "N0";
            }

            connection.Close();
        }

        private void slotsGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            DataGridViewRow row = slotsGridView.Rows[e.RowIndex];
            selectedSlotId = Convert.ToInt32(row.Cells["SlotId"].Value);
            txtSlotName.Text = row.Cells["SlotName"].Value.ToString();
            txtStartTime.Text = row.Cells["StartTime"].Value.ToString();
            txtEndTime.Text = row.Cells["EndTime"].Value.ToString();
            txtPrice.Text = row.Cells["PriceBDT"].Value.ToString();
        }

        private void btnAddSlot_Click(object sender, EventArgs e)
        {
            if (!(cboTurf.SelectedItem is TurfItem turf))
            {
                MessageBox.Show("Select a turf first.");
                return;
            }
            if (txtSlotName.Text == string.Empty || txtStartTime.Text == string.Empty
                || txtEndTime.Text == string.Empty || txtPrice.Text == string.Empty)
            {
                MessageBox.Show("All slot fields are required.");
                return;
            }

            SqlConnection connection = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string query = "INSERT INTO Slots (TurfId, SlotName, StartTime, EndTime, PriceBDT) "
                + "VALUES (@turfId, @name, @start, @end, @price)";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@turfId", turf.Id);
            cmd.Parameters.AddWithValue("@name", txtSlotName.Text.Trim());
            cmd.Parameters.AddWithValue("@start", txtStartTime.Text.Trim());
            cmd.Parameters.AddWithValue("@end", txtEndTime.Text.Trim());
            cmd.Parameters.AddWithValue("@price", decimal.Parse(txtPrice.Text.Trim()));
            cmd.ExecuteNonQuery();
            connection.Close();

            MessageBox.Show("Slot added!");
            ClearSlotFields();
            LoadSlotsGrid(turf.Id);
        }

        private void btnUpdateSlot_Click(object sender, EventArgs e)
        {
            if (selectedSlotId == -1)
            {
                MessageBox.Show("Select a slot from the grid first.");
                return;
            }

            SqlConnection connection = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string query = "UPDATE Slots SET SlotName=@name, StartTime=@start, "
                + "EndTime=@end, PriceBDT=@price WHERE SlotId=@id";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@name", txtSlotName.Text.Trim());
            cmd.Parameters.AddWithValue("@start", txtStartTime.Text.Trim());
            cmd.Parameters.AddWithValue("@end", txtEndTime.Text.Trim());
            cmd.Parameters.AddWithValue("@price", decimal.Parse(txtPrice.Text.Trim()));
            cmd.Parameters.AddWithValue("@id", selectedSlotId);
            cmd.ExecuteNonQuery();
            connection.Close();

            MessageBox.Show("Slot updated!");
            ClearSlotFields();
            if (cboTurf.SelectedItem is TurfItem turf)
                LoadSlotsGrid(turf.Id);
        }

        private void ClearSlotFields()
        {
            selectedSlotId = -1;
            txtSlotName.Clear(); txtStartTime.Clear();
            txtEndTime.Clear(); txtPrice.Clear();
        }
    }

    public class TurfItem
    {
        public int Id { get; }
        public string Name { get; }

        public TurfItem(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public override string ToString() => Name;
    }
}
