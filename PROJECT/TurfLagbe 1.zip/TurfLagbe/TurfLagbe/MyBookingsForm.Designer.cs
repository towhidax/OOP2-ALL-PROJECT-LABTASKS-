namespace TurfLagbe
{
    partial class MyBookingsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            panelHeader = new Panel();
            lblTitle = new Label();
            bookingsGridView = new DataGridView();
            cancelButton = new Button();
            lblStatus = new Label();
            panelHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)bookingsGridView).BeginInit();
            SuspendLayout();
            // 
            // panelHeader
            // 
            panelHeader.BackColor = Color.FromArgb(27, 58, 38);
            panelHeader.Controls.Add(lblTitle);
            panelHeader.Dock = DockStyle.Top;
            panelHeader.Name = "panelHeader";
            panelHeader.Size = new Size(780, 55);
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(18, 10);
            lblTitle.Name = "lblTitle";
            lblTitle.Text = "My Bookings";
            // 
            // bookingsGridView
            // 
            bookingsGridView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            bookingsGridView.AllowUserToAddRows = false;
            bookingsGridView.AllowUserToDeleteRows = false;
            bookingsGridView.AllowUserToResizeRows = false;
            bookingsGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            bookingsGridView.BackgroundColor = Color.White;
            bookingsGridView.BorderStyle = BorderStyle.None;
            bookingsGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(27, 58, 38);
            bookingsGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            bookingsGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            bookingsGridView.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(27, 58, 38);
            bookingsGridView.ColumnHeadersHeight = 38;
            bookingsGridView.DefaultCellStyle.Font = new Font("Segoe UI", 10F);
            bookingsGridView.DefaultCellStyle.SelectionBackColor = Color.FromArgb(200, 230, 201);
            bookingsGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            bookingsGridView.EnableHeadersVisualStyles = false;
            bookingsGridView.GridColor = Color.FromArgb(224, 224, 224);
            bookingsGridView.Location = new Point(20, 72);
            bookingsGridView.MultiSelect = false;
            bookingsGridView.Name = "bookingsGridView";
            bookingsGridView.ReadOnly = true;
            bookingsGridView.RowHeadersVisible = false;
            bookingsGridView.RowTemplate.Height = 36;
            bookingsGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            bookingsGridView.Size = new Size(740, 310);
            // 
            // cancelButton
            // 
            cancelButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            cancelButton.BackColor = Color.FromArgb(183, 28, 28);
            cancelButton.FlatAppearance.BorderSize = 0;
            cancelButton.FlatStyle = FlatStyle.Flat;
            cancelButton.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            cancelButton.ForeColor = Color.White;
            cancelButton.Location = new Point(20, 400);
            cancelButton.Name = "cancelButton";
            cancelButton.Size = new Size(180, 40);
            cancelButton.Text = "Cancel Selected";
            cancelButton.Cursor = Cursors.Hand;
            cancelButton.Click += cancelButton_Click;
            // 
            // lblStatus
            // 
            lblStatus.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            lblStatus.AutoSize = true;
            lblStatus.Font = new Font("Segoe UI", 9F);
            lblStatus.Location = new Point(215, 408);
            lblStatus.Name = "lblStatus";
            lblStatus.Text = "";
            // 
            // MyBookingsForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(245, 245, 245);
            ClientSize = new Size(780, 460);
            Controls.Add(lblStatus);
            Controls.Add(cancelButton);
            Controls.Add(bookingsGridView);
            Controls.Add(panelHeader);
            MinimumSize = new Size(600, 350);
            Name = "MyBookingsForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "My Bookings";
            Load += MyBookingsForm_Load;
            panelHeader.ResumeLayout(false);
            panelHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)bookingsGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panelHeader;
        private Label lblTitle;
        private DataGridView bookingsGridView;
        private Button cancelButton;
        private Label lblStatus;
    }
}
