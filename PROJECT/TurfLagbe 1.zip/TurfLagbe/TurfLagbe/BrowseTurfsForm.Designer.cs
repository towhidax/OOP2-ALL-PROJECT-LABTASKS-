namespace TurfLagbe
{
    partial class BrowseTurfsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            panelTop = new Panel();
            btnLogout = new Button();
            btnMyBookings = new Button();
            lblWelcome = new Label();
            lblTitle = new Label();
            flowTurfs = new FlowLayoutPanel();
            panelTop.SuspendLayout();
            SuspendLayout();
            // 
            // panelTop
            // 
            panelTop.BackColor = Color.FromArgb(27, 58, 38);
            panelTop.Controls.Add(btnLogout);
            panelTop.Controls.Add(btnMyBookings);
            panelTop.Controls.Add(lblWelcome);
            panelTop.Controls.Add(lblTitle);
            panelTop.Dock = DockStyle.Top;
            panelTop.Location = new Point(0, 0);
            panelTop.Name = "panelTop";
            panelTop.Size = new Size(1000, 65);
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(20, 14);
            lblTitle.Name = "lblTitle";
            lblTitle.Text = "⚽ Turf Lagbe";
            // 
            // lblWelcome
            // 
            lblWelcome.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI", 10F);
            lblWelcome.ForeColor = Color.FromArgb(160, 210, 180);
            lblWelcome.Location = new Point(560, 20);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Text = "Welcome";
            // 
            // btnMyBookings
            // 
            btnMyBookings.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMyBookings.BackColor = Color.FromArgb(56, 142, 60);
            btnMyBookings.FlatAppearance.BorderSize = 0;
            btnMyBookings.FlatStyle = FlatStyle.Flat;
            btnMyBookings.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnMyBookings.ForeColor = Color.White;
            btnMyBookings.Location = new Point(770, 15);
            btnMyBookings.Name = "btnMyBookings";
            btnMyBookings.Size = new Size(110, 35);
            btnMyBookings.Text = "My Bookings";
            btnMyBookings.Cursor = Cursors.Hand;
            btnMyBookings.Click += btnMyBookings_Click;
            // 
            // btnLogout
            // 
            btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLogout.BackColor = Color.FromArgb(183, 28, 28);
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.FlatStyle = FlatStyle.Flat;
            btnLogout.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnLogout.ForeColor = Color.White;
            btnLogout.Location = new Point(895, 15);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(85, 35);
            btnLogout.Text = "Logout";
            btnLogout.Cursor = Cursors.Hand;
            btnLogout.Click += btnLogout_Click;
            // 
            // flowTurfs
            // 
            flowTurfs.AutoScroll = true;
            flowTurfs.BackColor = Color.FromArgb(235, 235, 235);
            flowTurfs.Dock = DockStyle.Fill;
            flowTurfs.Padding = new Padding(30, 25, 30, 25);
            flowTurfs.Name = "flowTurfs";
            // 
            // BrowseTurfsForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 620);
            Controls.Add(flowTurfs);
            Controls.Add(panelTop);
            MinimumSize = new Size(750, 450);
            Name = "BrowseTurfsForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Turf Lagbe — Browse Turfs";
            Load += BrowseTurfsForm_Load;
            panelTop.ResumeLayout(false);
            panelTop.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelTop;
        private Label lblTitle;
        private Label lblWelcome;
        private Button btnMyBookings;
        private Button btnLogout;
        private FlowLayoutPanel flowTurfs;
    }
}
