using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurfLagbe
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            LoadBackgroundImage();
        }

        private void LoadBackgroundImage()
        {
            string imagePath = Path.Combine(Application.StartupPath, "imageLoginPage.jpg");
            if (File.Exists(imagePath))
            {
                this.BackgroundImage = Image.FromFile(imagePath);
            }
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            if (emailTextBox.Text == string.Empty
                || passwordTextBox.Text == string.Empty)
            {
                MessageBox.Show("Email and password both required");
                return;
            }

            SqlConnection connection
                = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string loginQuery = $"SELECT u.UserId, u.FullName, r.RoleName "
                + $"FROM Users u "
                + $"JOIN Roles r ON u.RoleId = r.RoleId "
                + $"WHERE u.Email = @email "
                + $"AND u.Password = @password "
                + $"AND u.Status = 'Active'";

            SqlCommand cmd = new SqlCommand(loginQuery, connection);
            cmd.Parameters.AddWithValue("@email", emailTextBox.Text.Trim());
            cmd.Parameters.AddWithValue("@password", passwordTextBox.Text);

            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                Session.UserId = reader.GetInt32(0);
                Session.FullName = reader.GetString(1);
                Session.Role = reader.GetString(2);
                reader.Close();
                connection.Close();

                Form nextForm;
                if (Session.Role == "Admin")
                    nextForm = new AdminForm();
                else if (Session.Role == "TurfManager")
                    nextForm = new ManagerForm();
                else
                    nextForm = new BrowseTurfsForm();

                nextForm.FormClosed += (s, args) =>
                {
                    Session.Clear();
                    passwordTextBox.Clear();
                    lblError.Text = "";
                    this.Show();
                };

                nextForm.Show();
                this.Hide();
            }
            else
            {
                reader.Close();
                connection.Close();
                lblError.Text = "Invalid email or password.";
            }
        }
    }
}
