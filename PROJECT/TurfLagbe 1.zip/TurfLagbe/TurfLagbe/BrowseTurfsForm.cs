using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurfLagbe
{
    public partial class BrowseTurfsForm : Form
    {
        public BrowseTurfsForm()
        {
            InitializeComponent();
        }

        private void BrowseTurfsForm_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = "Welcome, " + Session.FullName;
            LoadTurfs();
        }

        private void LoadTurfs()
        {
            flowTurfs.Controls.Clear();

            SqlConnection connection
                = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string query = "SELECT t.TurfId, t.TurfName, t.Area, "
                + "t.FieldType, t.Capacity, "
                + "MIN(s.PriceBDT) AS MinPrice, "
                + "MAX(s.PriceBDT) AS MaxPrice "
                + "FROM Turfs t "
                + "LEFT JOIN Slots s ON t.TurfId = s.TurfId AND s.IsActive = 1 "
                + "WHERE t.Status = 'Active' "
                + "GROUP BY t.TurfId, t.TurfName, t.Area, t.FieldType, t.Capacity";

            SqlCommand cmd = new SqlCommand(query, connection);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                int turfId = reader.GetInt32(0);
                string name = reader.GetString(1);
                string area = reader.IsDBNull(2) ? "" : reader.GetString(2);
                string fieldType = reader.IsDBNull(3) ? "" : reader.GetString(3);
                string capacity = reader.IsDBNull(4) ? "" : reader.GetString(4);
                decimal minPrice = reader.IsDBNull(5) ? 0 : reader.GetDecimal(5);
                decimal maxPrice = reader.IsDBNull(6) ? 0 : reader.GetDecimal(6);

                Panel card = CreateTurfCard(turfId, name, area,
                    fieldType, capacity, minPrice, maxPrice);
                flowTurfs.Controls.Add(card);
            }

            reader.Close();
            connection.Close();
        }

        private Panel CreateTurfCard(int turfId, string name, string area,
            string fieldType, string capacity,
            decimal minPrice, decimal maxPrice)
        {
            Panel card = new Panel();
            card.Size = new Size(290, 340);
            card.BackColor = Color.White;
            card.Margin = new Padding(15);

            PictureBox pic = new PictureBox();
            pic.Size = new Size(290, 150);
            pic.Location = new Point(0, 0);
            pic.SizeMode = PictureBoxSizeMode.StretchImage;
            pic.BackColor = Color.FromArgb(200, 200, 200);

            string imgPath = Path.Combine(Application.StartupPath,
                "turf" + turfId + ".jpg");
            if (File.Exists(imgPath))
                pic.Image = Image.FromFile(imgPath);

            Label lblName = new Label();
            lblName.Text = name;
            lblName.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            lblName.ForeColor = Color.FromArgb(27, 58, 38);
            lblName.Location = new Point(15, 160);
            lblName.Size = new Size(260, 30);

            Label lblInfo = new Label();
            lblInfo.Text = "📍 " + area + "  •  " + fieldType + "  •  " + capacity;
            lblInfo.Font = new Font("Segoe UI", 9F);
            lblInfo.ForeColor = Color.FromArgb(120, 120, 120);
            lblInfo.Location = new Point(15, 192);
            lblInfo.Size = new Size(260, 22);

            string priceText = (minPrice == maxPrice)
                ? $"৳{minPrice:N0}"
                : $"৳{minPrice:N0} – ৳{maxPrice:N0}";

            Label lblPrice = new Label();
            lblPrice.Text = priceText + " / slot";
            lblPrice.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblPrice.ForeColor = Color.FromArgb(46, 125, 50);
            lblPrice.Location = new Point(15, 225);
            lblPrice.AutoSize = true;

            Button btnBook = new Button();
            btnBook.Text = "Book Now";
            btnBook.BackColor = Color.FromArgb(46, 125, 50);
            btnBook.ForeColor = Color.White;
            btnBook.FlatStyle = FlatStyle.Flat;
            btnBook.FlatAppearance.BorderSize = 0;
            btnBook.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnBook.Size = new Size(260, 40);
            btnBook.Location = new Point(15, 275);
            btnBook.Cursor = Cursors.Hand;
            btnBook.Tag = turfId;
            btnBook.Click += btnBook_Click;

            card.Controls.Add(pic);
            card.Controls.Add(lblName);
            card.Controls.Add(lblInfo);
            card.Controls.Add(lblPrice);
            card.Controls.Add(btnBook);

            return card;
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            int turfId = (int)btn.Tag;
            BookSlotForm form = new BookSlotForm(turfId);
            form.ShowDialog();
        }

        private void btnMyBookings_Click(object sender, EventArgs e)
        {
            MyBookingsForm form = new MyBookingsForm();
            form.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
