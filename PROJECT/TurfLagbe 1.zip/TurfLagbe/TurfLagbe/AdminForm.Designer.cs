namespace TurfLagbe
{
    partial class AdminForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            panelHeader = new Panel();
            btnLogout = new Button();
            lblTitle = new Label();
            tabControl = new TabControl();
            tabBookings = new TabPage();
            lblFilter = new Label();
            cboFilter = new ComboBox();
            allBookingsGridView = new DataGridView();
            lblSummary = new Label();
            tabTurfs = new TabPage();
            turfsGridView = new DataGridView();
            lblTurfName = new Label(); txtTurfName = new TextBox();
            lblArea = new Label(); txtArea = new TextBox();
            lblAddress = new Label(); txtAddress = new TextBox();
            lblFieldType = new Label(); cboFieldType = new ComboBox();
            lblCapacity = new Label(); txtCapacity = new TextBox();
            lblPhone = new Label(); txtPhone = new TextBox();
            btnAddTurf = new Button(); btnUpdateTurf = new Button();
            tabSlots = new TabPage();
            lblSelectTurf = new Label(); cboTurf = new ComboBox();
            slotsGridView = new DataGridView();
            lblSlotName = new Label(); txtSlotName = new TextBox();
            lblStartTime = new Label(); txtStartTime = new TextBox();
            lblEndTime = new Label(); txtEndTime = new TextBox();
            lblPrice = new Label(); txtPrice = new TextBox();
            btnAddSlot = new Button(); btnUpdateSlot = new Button();

            panelHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)allBookingsGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)turfsGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)slotsGridView).BeginInit();
            SuspendLayout();

            // ── Header ──
            panelHeader.BackColor = Color.FromArgb(27, 58, 38);
            panelHeader.Controls.Add(btnLogout);
            panelHeader.Controls.Add(lblTitle);
            panelHeader.Dock = DockStyle.Top;
            panelHeader.Size = new Size(1100, 55);

            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(18, 10);
            lblTitle.Text = "⚽ Turf Lagbe — Admin Panel";

            btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLogout.BackColor = Color.FromArgb(183, 28, 28);
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.FlatStyle = FlatStyle.Flat;
            btnLogout.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnLogout.ForeColor = Color.White;
            btnLogout.Location = new Point(990, 12);
            btnLogout.Size = new Size(85, 33);
            btnLogout.Text = "Logout";
            btnLogout.Cursor = Cursors.Hand;
            btnLogout.Click += btnLogout_Click;

            // ── TabControl ──
            tabControl.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tabControl.Controls.Add(tabBookings);
            tabControl.Controls.Add(tabTurfs);
            tabControl.Controls.Add(tabSlots);
            tabControl.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            tabControl.Location = new Point(10, 60);
            tabControl.Size = new Size(1080, 530);

            // ═══ TAB 1: ALL BOOKINGS ═══
            tabBookings.Text = "  All Bookings  ";
            tabBookings.BackColor = Color.FromArgb(245, 245, 245);

            lblFilter.AutoSize = true;
            lblFilter.Location = new Point(15, 15);
            lblFilter.Text = "Filter:";

            cboFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFilter.Font = new Font("Segoe UI", 10F);
            cboFilter.Items.AddRange(new object[] { "All", "Pending", "Confirmed", "Cancelled" });
            cboFilter.Location = new Point(75, 12);
            cboFilter.Size = new Size(140, 31);
            cboFilter.SelectedIndexChanged += cboFilter_SelectedIndexChanged;

            allBookingsGridView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            allBookingsGridView.AllowUserToAddRows = false;
            allBookingsGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            allBookingsGridView.BackgroundColor = Color.White;
            allBookingsGridView.BorderStyle = BorderStyle.None;
            allBookingsGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(27, 58, 38);
            allBookingsGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            allBookingsGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            allBookingsGridView.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(27, 58, 38);
            allBookingsGridView.ColumnHeadersHeight = 38;
            allBookingsGridView.DefaultCellStyle.Font = new Font("Segoe UI", 10F);
            allBookingsGridView.DefaultCellStyle.SelectionBackColor = Color.FromArgb(200, 230, 201);
            allBookingsGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            allBookingsGridView.EnableHeadersVisualStyles = false;
            allBookingsGridView.Location = new Point(15, 52);
            allBookingsGridView.ReadOnly = true;
            allBookingsGridView.RowHeadersVisible = false;
            allBookingsGridView.RowTemplate.Height = 34;
            allBookingsGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            allBookingsGridView.Size = new Size(1030, 380);

            lblSummary.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            lblSummary.AutoSize = true;
            lblSummary.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblSummary.ForeColor = Color.FromArgb(46, 125, 50);
            lblSummary.Location = new Point(15, 440);
            lblSummary.Text = "";

            tabBookings.Controls.Add(lblFilter);
            tabBookings.Controls.Add(cboFilter);
            tabBookings.Controls.Add(allBookingsGridView);
            tabBookings.Controls.Add(lblSummary);

            // ═══ TAB 2: MANAGE TURFS ═══
            tabTurfs.Text = "  Manage Turfs  ";
            tabTurfs.BackColor = Color.FromArgb(245, 245, 245);

            turfsGridView.AllowUserToAddRows = false;
            turfsGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            turfsGridView.BackgroundColor = Color.White;
            turfsGridView.BorderStyle = BorderStyle.None;
            turfsGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(27, 58, 38);
            turfsGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            turfsGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            turfsGridView.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(27, 58, 38);
            turfsGridView.ColumnHeadersHeight = 38;
            turfsGridView.DefaultCellStyle.Font = new Font("Segoe UI", 10F);
            turfsGridView.DefaultCellStyle.SelectionBackColor = Color.FromArgb(200, 230, 201);
            turfsGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            turfsGridView.EnableHeadersVisualStyles = false;
            turfsGridView.Location = new Point(15, 15);
            turfsGridView.ReadOnly = true;
            turfsGridView.RowHeadersVisible = false;
            turfsGridView.RowTemplate.Height = 34;
            turfsGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            turfsGridView.Size = new Size(1030, 195);
            turfsGridView.CellClick += turfsGridView_CellClick;

            int y1 = 225; int c1 = 15; int c2 = 280; int c3 = 545;
            lblTurfName.AutoSize = true; lblTurfName.Location = new Point(c1, y1); lblTurfName.Text = "Turf Name:";
            txtTurfName.Location = new Point(c1, y1 + 25); txtTurfName.Size = new Size(240, 31);
            lblArea.AutoSize = true; lblArea.Location = new Point(c2, y1); lblArea.Text = "Area:";
            txtArea.Location = new Point(c2, y1 + 25); txtArea.Size = new Size(240, 31);
            lblAddress.AutoSize = true; lblAddress.Location = new Point(c3, y1); lblAddress.Text = "Address:";
            txtAddress.Location = new Point(c3, y1 + 25); txtAddress.Size = new Size(500, 31);

            int y2 = y1 + 70;
            lblFieldType.AutoSize = true; lblFieldType.Location = new Point(c1, y2); lblFieldType.Text = "Field Type:";
            cboFieldType.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFieldType.Items.AddRange(new object[] { "Indoor", "Outdoor" });
            cboFieldType.Location = new Point(c1, y2 + 25); cboFieldType.Size = new Size(240, 31); cboFieldType.SelectedIndex = 0;
            lblCapacity.AutoSize = true; lblCapacity.Location = new Point(c2, y2); lblCapacity.Text = "Capacity:";
            txtCapacity.Location = new Point(c2, y2 + 25); txtCapacity.Size = new Size(240, 31);
            lblPhone.AutoSize = true; lblPhone.Location = new Point(c3, y2); lblPhone.Text = "Phone:";
            txtPhone.Location = new Point(c3, y2 + 25); txtPhone.Size = new Size(240, 31);

            int yBtn = y2 + 75;
            btnAddTurf.BackColor = Color.FromArgb(46, 125, 50);
            btnAddTurf.FlatAppearance.BorderSize = 0; btnAddTurf.FlatStyle = FlatStyle.Flat;
            btnAddTurf.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnAddTurf.ForeColor = Color.White; btnAddTurf.Location = new Point(c1, yBtn);
            btnAddTurf.Size = new Size(150, 40); btnAddTurf.Text = "Add Turf";
            btnAddTurf.Cursor = Cursors.Hand; btnAddTurf.Click += btnAddTurf_Click;

            btnUpdateTurf.BackColor = Color.FromArgb(33, 150, 243);
            btnUpdateTurf.FlatAppearance.BorderSize = 0; btnUpdateTurf.FlatStyle = FlatStyle.Flat;
            btnUpdateTurf.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnUpdateTurf.ForeColor = Color.White; btnUpdateTurf.Location = new Point(180, yBtn);
            btnUpdateTurf.Size = new Size(160, 40); btnUpdateTurf.Text = "Update Turf";
            btnUpdateTurf.Cursor = Cursors.Hand; btnUpdateTurf.Click += btnUpdateTurf_Click;

            tabTurfs.Controls.Add(turfsGridView);
            tabTurfs.Controls.Add(lblTurfName); tabTurfs.Controls.Add(txtTurfName);
            tabTurfs.Controls.Add(lblArea); tabTurfs.Controls.Add(txtArea);
            tabTurfs.Controls.Add(lblAddress); tabTurfs.Controls.Add(txtAddress);
            tabTurfs.Controls.Add(lblFieldType); tabTurfs.Controls.Add(cboFieldType);
            tabTurfs.Controls.Add(lblCapacity); tabTurfs.Controls.Add(txtCapacity);
            tabTurfs.Controls.Add(lblPhone); tabTurfs.Controls.Add(txtPhone);
            tabTurfs.Controls.Add(btnAddTurf); tabTurfs.Controls.Add(btnUpdateTurf);

            // ═══ TAB 3: MANAGE SLOTS ═══
            tabSlots.Text = "  Manage Slots  ";
            tabSlots.BackColor = Color.FromArgb(245, 245, 245);

            lblSelectTurf.AutoSize = true; lblSelectTurf.Location = new Point(15, 15); lblSelectTurf.Text = "Select Turf:";
            cboTurf.DropDownStyle = ComboBoxStyle.DropDownList; cboTurf.Font = new Font("Segoe UI", 10F);
            cboTurf.Location = new Point(130, 12); cboTurf.Size = new Size(250, 31);
            cboTurf.SelectedIndexChanged += cboTurf_SelectedIndexChanged;

            slotsGridView.AllowUserToAddRows = false;
            slotsGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            slotsGridView.BackgroundColor = Color.White; slotsGridView.BorderStyle = BorderStyle.None;
            slotsGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(27, 58, 38);
            slotsGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            slotsGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            slotsGridView.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(27, 58, 38);
            slotsGridView.ColumnHeadersHeight = 38;
            slotsGridView.DefaultCellStyle.Font = new Font("Segoe UI", 10F);
            slotsGridView.DefaultCellStyle.SelectionBackColor = Color.FromArgb(200, 230, 201);
            slotsGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            slotsGridView.EnableHeadersVisualStyles = false;
            slotsGridView.Location = new Point(15, 55); slotsGridView.ReadOnly = true;
            slotsGridView.RowHeadersVisible = false; slotsGridView.RowTemplate.Height = 34;
            slotsGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            slotsGridView.Size = new Size(1030, 195);
            slotsGridView.CellClick += slotsGridView_CellClick;

            int sy = 265;
            lblSlotName.AutoSize = true; lblSlotName.Location = new Point(c1, sy); lblSlotName.Text = "Slot Name:";
            txtSlotName.Location = new Point(c1, sy + 25); txtSlotName.Size = new Size(200, 31);
            lblStartTime.AutoSize = true; lblStartTime.Location = new Point(c2, sy); lblStartTime.Text = "Start (HH:mm):";
            txtStartTime.Location = new Point(c2, sy + 25); txtStartTime.Size = new Size(150, 31);
            lblEndTime.AutoSize = true; lblEndTime.Location = new Point(470, sy); lblEndTime.Text = "End (HH:mm):";
            txtEndTime.Location = new Point(470, sy + 25); txtEndTime.Size = new Size(150, 31);
            lblPrice.AutoSize = true; lblPrice.Location = new Point(660, sy); lblPrice.Text = "Price (BDT):";
            txtPrice.Location = new Point(660, sy + 25); txtPrice.Size = new Size(150, 31);

            int syBtn = sy + 75;
            btnAddSlot.BackColor = Color.FromArgb(46, 125, 50);
            btnAddSlot.FlatAppearance.BorderSize = 0; btnAddSlot.FlatStyle = FlatStyle.Flat;
            btnAddSlot.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnAddSlot.ForeColor = Color.White; btnAddSlot.Location = new Point(c1, syBtn);
            btnAddSlot.Size = new Size(150, 40); btnAddSlot.Text = "Add Slot";
            btnAddSlot.Cursor = Cursors.Hand; btnAddSlot.Click += btnAddSlot_Click;

            btnUpdateSlot.BackColor = Color.FromArgb(33, 150, 243);
            btnUpdateSlot.FlatAppearance.BorderSize = 0; btnUpdateSlot.FlatStyle = FlatStyle.Flat;
            btnUpdateSlot.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnUpdateSlot.ForeColor = Color.White; btnUpdateSlot.Location = new Point(180, syBtn);
            btnUpdateSlot.Size = new Size(160, 40); btnUpdateSlot.Text = "Update Slot";
            btnUpdateSlot.Cursor = Cursors.Hand; btnUpdateSlot.Click += btnUpdateSlot_Click;

            tabSlots.Controls.Add(lblSelectTurf); tabSlots.Controls.Add(cboTurf);
            tabSlots.Controls.Add(slotsGridView);
            tabSlots.Controls.Add(lblSlotName); tabSlots.Controls.Add(txtSlotName);
            tabSlots.Controls.Add(lblStartTime); tabSlots.Controls.Add(txtStartTime);
            tabSlots.Controls.Add(lblEndTime); tabSlots.Controls.Add(txtEndTime);
            tabSlots.Controls.Add(lblPrice); tabSlots.Controls.Add(txtPrice);
            tabSlots.Controls.Add(btnAddSlot); tabSlots.Controls.Add(btnUpdateSlot);

            // ── AdminForm ──
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1100, 600);
            Controls.Add(tabControl); Controls.Add(panelHeader);
            MinimumSize = new Size(900, 500);
            Name = "AdminForm"; StartPosition = FormStartPosition.CenterScreen;
            Text = "Turf Lagbe — Admin Panel";
            Load += AdminForm_Load;
            panelHeader.ResumeLayout(false); panelHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)allBookingsGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)turfsGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)slotsGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelHeader; private Label lblTitle; private Button btnLogout;
        private TabControl tabControl;
        private TabPage tabBookings; private Label lblFilter; private ComboBox cboFilter;
        private DataGridView allBookingsGridView; private Label lblSummary;
        private TabPage tabTurfs; private DataGridView turfsGridView;
        private Label lblTurfName; private TextBox txtTurfName;
        private Label lblArea; private TextBox txtArea;
        private Label lblAddress; private TextBox txtAddress;
        private Label lblFieldType; private ComboBox cboFieldType;
        private Label lblCapacity; private TextBox txtCapacity;
        private Label lblPhone; private TextBox txtPhone;
        private Button btnAddTurf; private Button btnUpdateTurf;
        private TabPage tabSlots; private Label lblSelectTurf; private ComboBox cboTurf;
        private DataGridView slotsGridView;
        private Label lblSlotName; private TextBox txtSlotName;
        private Label lblStartTime; private TextBox txtStartTime;
        private Label lblEndTime; private TextBox txtEndTime;
        private Label lblPrice; private TextBox txtPrice;
        private Button btnAddSlot; private Button btnUpdateSlot;
    }
}
