using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurfLagbe
{
    public partial class BookSlotForm : Form
    {
        private readonly int _turfId;

        public BookSlotForm(int turfId)
        {
            InitializeComponent();
            _turfId = turfId;
            LoadTurfName();
            LoadSlots();
        }

        private void LoadTurfName()
        {
            SqlConnection connection
                = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            SqlCommand cmd = new SqlCommand(
                "SELECT TurfName FROM Turfs WHERE TurfId = @id",
                connection);
            cmd.Parameters.AddWithValue("@id", _turfId);

            object result = cmd.ExecuteScalar();
            lblTurfName.Text = result != null ? result.ToString() : "Turf";

            connection.Close();
        }

        private void dtpDate_ValueChanged(object sender, EventArgs e)
        {
            LoadSlots();
        }

        private void LoadSlots()
        {
            SqlConnection connection
                = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string query = "SELECT s.SlotId, s.SlotName, "
                + "CONVERT(VARCHAR(5), s.StartTime, 108) + ' - ' + "
                + "CONVERT(VARCHAR(5), s.EndTime, 108) AS TimeRange, "
                + "s.PriceBDT "
                + "FROM Slots s "
                + "WHERE s.TurfId = @turfId AND s.IsActive = 1 "
                + "AND s.SlotId NOT IN ( "
                + "    SELECT b.SlotId FROM Bookings b "
                + "    WHERE b.TurfId = @turfId "
                + "    AND b.BookingDate = @bookDate "
                + "    AND b.BookingStatus IN ('Pending','Confirmed') "
                + ") "
                + "ORDER BY s.StartTime";

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@turfId", _turfId);
            cmd.Parameters.AddWithValue("@bookDate", dtpDate.Value.Date);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            slotsGridView.DataSource = dataTable;

            connection.Close();

            if (slotsGridView.Columns.Contains("SlotId"))
                slotsGridView.Columns["SlotId"].Visible = false;

            if (slotsGridView.Columns.Contains("SlotName"))
                slotsGridView.Columns["SlotName"].HeaderText = "Slot";

            if (slotsGridView.Columns.Contains("TimeRange"))
                slotsGridView.Columns["TimeRange"].HeaderText = "Time";

            if (slotsGridView.Columns.Contains("PriceBDT"))
            {
                slotsGridView.Columns["PriceBDT"].HeaderText = "Price (৳)";
                slotsGridView.Columns["PriceBDT"].DefaultCellStyle.Format = "N0";
            }

            if (slotsGridView.Rows.Count == 0)
            {
                lblStatus.Text = "No available slots for this date.";
                lblStatus.ForeColor = Color.FromArgb(120, 120, 120);
            }
            else
            {
                lblStatus.Text = "";
            }
        }

        private void bookButton_Click(object sender, EventArgs e)
        {
            if (slotsGridView.SelectedRows.Count == 0)
            {
                lblStatus.Text = "Please select a slot first.";
                lblStatus.ForeColor = Color.FromArgb(211, 47, 47);
                return;
            }

            DataGridViewRow row = slotsGridView.SelectedRows[0];
            int slotId = Convert.ToInt32(row.Cells["SlotId"].Value);
            string slotName = row.Cells["SlotName"].Value.ToString();
            decimal price = Convert.ToDecimal(row.Cells["PriceBDT"].Value);

            DialogResult confirm = MessageBox.Show(
                $"Book {slotName} on {dtpDate.Value:dd MMM yyyy} for ৳{price:N0}?",
                "Confirm Booking",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes)
                return;

            SqlConnection connection
                = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string insertBooking = "INSERT INTO Bookings "
                + "(UserId, TurfId, SlotId, BookingDate, TotalAmount, BookingStatus) "
                + "OUTPUT INSERTED.BookingId "
                + "VALUES (@userId, @turfId, @slotId, @bookDate, @amount, 'Confirmed')";

            SqlCommand cmd = new SqlCommand(insertBooking, connection);
            cmd.Parameters.AddWithValue("@userId", Session.UserId);
            cmd.Parameters.AddWithValue("@turfId", _turfId);
            cmd.Parameters.AddWithValue("@slotId", slotId);
            cmd.Parameters.AddWithValue("@bookDate", dtpDate.Value.Date);
            cmd.Parameters.AddWithValue("@amount", price);
            int bookingId = (int)cmd.ExecuteScalar();

            string txn = "TXN-" + DateTime.Now.ToString("yyyyMMddHHmmss")
                + "-" + bookingId;

            string insertPayment = "INSERT INTO Payments "
                + "(BookingId, UserId, Amount, PaymentMethod, TransactionNo, Status) "
                + "VALUES (@bookingId, @userId, @amount, 'bKash', @txn, 'Completed')";

            SqlCommand cmd2 = new SqlCommand(insertPayment, connection);
            cmd2.Parameters.AddWithValue("@bookingId", bookingId);
            cmd2.Parameters.AddWithValue("@userId", Session.UserId);
            cmd2.Parameters.AddWithValue("@amount", price);
            cmd2.Parameters.AddWithValue("@txn", txn);
            cmd2.ExecuteNonQuery();

            connection.Close();

            lblStatus.Text = "✓ Booked successfully!";
            lblStatus.ForeColor = Color.FromArgb(46, 125, 50);

            LoadSlots();
        }
    }
}
