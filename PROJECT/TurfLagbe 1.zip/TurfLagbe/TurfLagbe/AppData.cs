namespace TurfLagbe
{
    public class AppData
    {
        public static readonly string ConnectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=TurfBookingSystem;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
    }
}
