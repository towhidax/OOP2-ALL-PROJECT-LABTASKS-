namespace TurfLagbe
{
    partial class BookSlotForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            panelHeader = new Panel();
            lblTurfName = new Label();
            lblPickDate = new Label();
            dtpDate = new DateTimePicker();
            slotsGridView = new DataGridView();
            bookButton = new Button();
            lblStatus = new Label();
            panelHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)slotsGridView).BeginInit();
            SuspendLayout();
            // 
            // panelHeader
            // 
            panelHeader.BackColor = Color.FromArgb(27, 58, 38);
            panelHeader.Controls.Add(lblTurfName);
            panelHeader.Dock = DockStyle.Top;
            panelHeader.Name = "panelHeader";
            panelHeader.Size = new Size(560, 55);
            // 
            // lblTurfName
            // 
            lblTurfName.AutoSize = true;
            lblTurfName.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblTurfName.ForeColor = Color.White;
            lblTurfName.Location = new Point(18, 10);
            lblTurfName.Name = "lblTurfName";
            lblTurfName.Text = "Turf Name";
            // 
            // lblPickDate
            // 
            lblPickDate.AutoSize = true;
            lblPickDate.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblPickDate.Location = new Point(25, 72);
            lblPickDate.Name = "lblPickDate";
            lblPickDate.Text = "Select Date:";
            // 
            // dtpDate
            // 
            dtpDate.Font = new Font("Segoe UI", 11F);
            dtpDate.Format = DateTimePickerFormat.Short;
            dtpDate.Location = new Point(135, 68);
            dtpDate.MinDate = DateTime.Today;
            dtpDate.Name = "dtpDate";
            dtpDate.Size = new Size(180, 32);
            dtpDate.ValueChanged += dtpDate_ValueChanged;
            // 
            // slotsGridView
            // 
            slotsGridView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            slotsGridView.AllowUserToAddRows = false;
            slotsGridView.AllowUserToDeleteRows = false;
            slotsGridView.AllowUserToResizeRows = false;
            slotsGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            slotsGridView.BackgroundColor = Color.White;
            slotsGridView.BorderStyle = BorderStyle.None;
            slotsGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(27, 58, 38);
            slotsGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            slotsGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            slotsGridView.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(27, 58, 38);
            slotsGridView.ColumnHeadersHeight = 38;
            slotsGridView.DefaultCellStyle.Font = new Font("Segoe UI", 10F);
            slotsGridView.DefaultCellStyle.SelectionBackColor = Color.FromArgb(200, 230, 201);
            slotsGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            slotsGridView.EnableHeadersVisualStyles = false;
            slotsGridView.GridColor = Color.FromArgb(224, 224, 224);
            slotsGridView.Location = new Point(25, 115);
            slotsGridView.MultiSelect = false;
            slotsGridView.Name = "slotsGridView";
            slotsGridView.ReadOnly = true;
            slotsGridView.RowHeadersVisible = false;
            slotsGridView.RowTemplate.Height = 36;
            slotsGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            slotsGridView.Size = new Size(510, 240);
            // 
            // bookButton
            // 
            bookButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            bookButton.BackColor = Color.FromArgb(46, 125, 50);
            bookButton.FlatAppearance.BorderSize = 0;
            bookButton.FlatStyle = FlatStyle.Flat;
            bookButton.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            bookButton.ForeColor = Color.White;
            bookButton.Location = new Point(25, 375);
            bookButton.Name = "bookButton";
            bookButton.Size = new Size(510, 45);
            bookButton.Text = "Confirm Booking";
            bookButton.Cursor = Cursors.Hand;
            bookButton.Click += bookButton_Click;
            // 
            // lblStatus
            // 
            lblStatus.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            lblStatus.Font = new Font("Segoe UI", 9F);
            lblStatus.ForeColor = Color.FromArgb(211, 47, 47);
            lblStatus.Location = new Point(25, 428);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(510, 25);
            lblStatus.Text = "";
            // 
            // BookSlotForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(245, 245, 245);
            ClientSize = new Size(560, 465);
            Controls.Add(lblStatus);
            Controls.Add(bookButton);
            Controls.Add(slotsGridView);
            Controls.Add(dtpDate);
            Controls.Add(lblPickDate);
            Controls.Add(panelHeader);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "BookSlotForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Book a Slot";
            panelHeader.ResumeLayout(false);
            panelHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)slotsGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panelHeader;
        private Label lblTurfName;
        private Label lblPickDate;
        private DateTimePicker dtpDate;
        private DataGridView slotsGridView;
        private Button bookButton;
        private Label lblStatus;
    }
}
