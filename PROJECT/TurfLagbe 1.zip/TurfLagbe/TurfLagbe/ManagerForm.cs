using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TurfLagbe
{
    public partial class ManagerForm : Form
    {
        private int _turfId = -1;
        private string _turfName = "";

        public ManagerForm()
        {
            InitializeComponent();
        }

        private void ManagerForm_Load(object sender, EventArgs e)
        {
            LoadManagerTurf();
            cboFilter.SelectedIndex = 0;
            LoadBookings();
        }

        private void LoadManagerTurf()
        {
            SqlConnection connection
                = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string query = "SELECT t.TurfId, t.TurfName "
                + "FROM TurfManagers tm "
                + "JOIN Turfs t ON tm.TurfId = t.TurfId "
                + "WHERE tm.UserId = @userId";

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@userId", Session.UserId);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                _turfId = reader.GetInt32(0);
                _turfName = reader.GetString(1);
                lblTurfInfo.Text = Session.FullName + "  |  " + _turfName;
            }
            else
            {
                lblTurfInfo.Text = Session.FullName + "  |  No turf assigned";
            }

            reader.Close();
            connection.Close();
        }

        private void cboFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadBookings();
        }

        private void LoadBookings()
        {
            if (_turfId == -1) return;

            SqlConnection connection
                = new SqlConnection(AppData.ConnectionString);
            connection.Open();

            string filter = cboFilter.SelectedItem.ToString();
            string where = "WHERE b.TurfId = @turfId";
            if (filter != "All")
                where += " AND b.BookingStatus = @status";

            string query = "SELECT b.BookingId AS [#], "
                + "u.FullName AS [Booked By], "
                + "s.SlotName AS [Slot], "
                + "CONVERT(VARCHAR(5), s.StartTime, 108) + ' - ' + "
                + "CONVERT(VARCHAR(5), s.EndTime, 108) AS [Time], "
                + "CONVERT(VARCHAR(10), b.BookingDate, 120) AS [Date], "
                + "b.TotalAmount AS [Amount], "
                + "b.BookingStatus AS [Status], "
                + "ISNULL(p.PaymentMethod, '-') AS [Payment] "
                + "FROM Bookings b "
                + "JOIN Users u ON b.UserId = u.UserId "
                + "JOIN Slots s ON b.SlotId = s.SlotId "
                + "LEFT JOIN Payments p ON b.BookingId = p.BookingId "
                + where + " "
                + "ORDER BY b.BookingDate DESC, s.StartTime DESC";

            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@turfId", _turfId);
            if (filter != "All")
                cmd.Parameters.AddWithValue("@status", filter);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            managerGridView.DataSource = dt;

            if (managerGridView.Columns.Contains("Amount"))
                managerGridView.Columns["Amount"].DefaultCellStyle.Format = "N0";

            string revQuery = "SELECT "
                + "COUNT(*) AS Total, "
                + "SUM(CASE WHEN BookingStatus='Confirmed' THEN 1 ELSE 0 END) AS Confirmed, "
                + "SUM(CASE WHEN BookingStatus='Cancelled' THEN 1 ELSE 0 END) AS Cancelled, "
                + "SUM(CASE WHEN BookingStatus='Confirmed' THEN TotalAmount ELSE 0 END) AS Revenue "
                + "FROM Bookings WHERE TurfId = @turfId2";

            SqlCommand cmd2 = new SqlCommand(revQuery, connection);
            cmd2.Parameters.AddWithValue("@turfId2", _turfId);
            SqlDataReader reader = cmd2.ExecuteReader();

            if (reader.Read())
            {
                int total = reader.GetInt32(0);
                int confirmed = reader.IsDBNull(1) ? 0 : reader.GetInt32(1);
                int cancelled = reader.IsDBNull(2) ? 0 : reader.GetInt32(2);
                decimal revenue = reader.IsDBNull(3) ? 0 : reader.GetDecimal(3);

                lblRevenue.Text = $"Total: {total}   |   Confirmed: {confirmed}   |   "
                    + $"Cancelled: {cancelled}   |   Revenue: ৳{revenue:N0}";
            }

            reader.Close();
            connection.Close();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
