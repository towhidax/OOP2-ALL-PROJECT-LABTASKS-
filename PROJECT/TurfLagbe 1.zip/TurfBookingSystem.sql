CREATE DATABASE TurfBookingSystem;
GO

USE TurfBookingSystem;
GO

-- =========================================
-- ROLES
-- =========================================

CREATE TABLE Roles (
    RoleId   INT PRIMARY KEY IDENTITY(1,1),
    RoleName NVARCHAR(50) UNIQUE NOT NULL
);

INSERT INTO Roles (RoleName) VALUES
('Admin'),
('TurfManager'),
('User');

-- =========================================
-- USERS
-- =========================================

CREATE TABLE Users (
    UserId    INT PRIMARY KEY IDENTITY(1,1),
    FullName  NVARCHAR(100) NOT NULL,
    Username  NVARCHAR(50)  UNIQUE NOT NULL,
    Email     NVARCHAR(100) UNIQUE NOT NULL,
    Phone     NVARCHAR(20),
    Password  NVARCHAR(255) NOT NULL,
    RoleId    INT NOT NULL,
    Status    NVARCHAR(20)  DEFAULT 'Active',
    CreatedAt DATETIME      DEFAULT GETDATE(),

    FOREIGN KEY (RoleId) REFERENCES Roles(RoleId)
);

INSERT INTO Users (FullName, Username, Email, Phone, Password, RoleId) VALUES
('System Admin',  'admin',   'admin@turfbook.com',    '01711000001', 'hashed_pw', 1),
('Karim Hossain', 'karim',   'karim@turfbook.com',    '01822000002', 'hashed_pw', 2),
('Rafi Ahmed',    'rafi',    'rafi@turfbook.com',      '01822000003', 'hashed_pw', 2),
('Sumon Islam',   'sumon',   'sumon@turfbook.com',     '01822000004', 'hashed_pw', 2),
('Rahim Uddin',   'rahim',   'rahim@gmail.com',        '01933000005', 'hashed_pw', 3),
('Nusrat Jahan',  'nusrat',  'nusrat@gmail.com',       '01933000006', 'hashed_pw', 3),
('Tanvir Khan',   'tanvir',  'tanvir@gmail.com',       '01933000007', 'hashed_pw', 3);

-- =========================================
-- TURFS
-- =========================================

CREATE TABLE Turfs (
    TurfId      INT PRIMARY KEY IDENTITY(1,1),
    TurfName    NVARCHAR(100) NOT NULL,
    Area        NVARCHAR(100),
    Address     NVARCHAR(MAX),
    FieldType   NVARCHAR(50),
    Capacity    NVARCHAR(50),
    Phone       NVARCHAR(20),
    Status      NVARCHAR(20) DEFAULT 'Active',
    CreatedAt   DATETIME     DEFAULT GETDATE()
);

INSERT INTO Turfs (TurfName, Area, Address, FieldType, Capacity, Phone) VALUES
('JAFF Arena & Academy', 'Bashundhara', 'Bashundhara Main Gate, Dhaka 1229',           'Indoor',  '6-a-side', NULL),
('Turf Nation',          'Tejgaon',     '115/116 Tejgaon Industrial Area, Dhaka 1208',  'Indoor',  '6-a-side', '+880 1814-460000'),
('DSF',                  'Hazaribagh',  'Pilkhana Road, Dhaka 1205',                    'Outdoor', '5-a-side', '+880 1788-857133');

-- =========================================
-- TURF MANAGERS
-- =========================================

CREATE TABLE TurfManagers (
    AssignId   INT PRIMARY KEY IDENTITY(1,1),
    TurfId     INT NOT NULL,
    UserId     INT NOT NULL,
    AssignedAt DATETIME DEFAULT GETDATE(),

    FOREIGN KEY (TurfId) REFERENCES Turfs(TurfId),
    FOREIGN KEY (UserId) REFERENCES Users(UserId)
);

INSERT INTO TurfManagers (TurfId, UserId) VALUES
(1, 2),   -- Karim  -> JAFF Arena
(2, 3),   -- Rafi   -> Turf Nation
(3, 4);   -- Sumon  -> DSF

-- =========================================
-- SLOTS
-- =========================================

CREATE TABLE Slots (
    SlotId      INT PRIMARY KEY IDENTITY(1,1),
    TurfId      INT NOT NULL,
    SlotName    NVARCHAR(50)  NOT NULL,
    StartTime   TIME          NOT NULL,
    EndTime     TIME          NOT NULL,
    PriceBDT    DECIMAL(10,2) NOT NULL,
    IsActive    BIT           DEFAULT 1,

    FOREIGN KEY (TurfId) REFERENCES Turfs(TurfId)
);

-- JAFF Arena (TurfId = 1)
INSERT INTO Slots (TurfId, SlotName, StartTime, EndTime, PriceBDT) VALUES
(1, 'Morning',   '06:30', '08:00', 3500),
(1, 'Afternoon', '13:00', '14:30', 4500),
(1, 'Evening',   '17:00', '18:30', 6000),
(1, 'Night',     '20:00', '21:30', 6000);

-- Turf Nation (TurfId = 2)
INSERT INTO Slots (TurfId, SlotName, StartTime, EndTime, PriceBDT) VALUES
(2, 'Morning',   '07:00', '08:30', 2500),
(2, 'Afternoon', '12:00', '13:30', 3000),
(2, 'Evening',   '17:00', '18:30', 4000);

-- DSF (TurfId = 3)
INSERT INTO Slots (TurfId, SlotName, StartTime, EndTime, PriceBDT) VALUES
(3, 'Morning', '07:30', '09:00', 3000),
(3, 'Evening', '17:00', '18:30', 3500);

-- =========================================
-- BOOKINGS
-- =========================================

CREATE TABLE Bookings (
    BookingId     INT PRIMARY KEY IDENTITY(1,1),
    UserId        INT NOT NULL,
    TurfId        INT NOT NULL,
    SlotId        INT NOT NULL,
    BookingDate   DATE          NOT NULL,
    TotalAmount   DECIMAL(10,2) NOT NULL,
    BookingStatus NVARCHAR(30)  DEFAULT 'Pending',
    BookedAt      DATETIME      DEFAULT GETDATE(),

    FOREIGN KEY (UserId) REFERENCES Users(UserId),
    FOREIGN KEY (TurfId) REFERENCES Turfs(TurfId),
    FOREIGN KEY (SlotId) REFERENCES Slots(SlotId)
);

INSERT INTO Bookings (UserId, TurfId, SlotId, BookingDate, TotalAmount, BookingStatus) VALUES
(5, 1, 1, '2026-05-20', 3500, 'Confirmed'),
(6, 2, 5, '2026-05-21', 2500, 'Confirmed'),
(7, 3, 8, '2026-05-22', 3000, 'Pending'),
(5, 1, 3, '2026-05-23', 6000, 'Cancelled');

-- =========================================
-- PAYMENTS
-- =========================================

CREATE TABLE Payments (
    PaymentId     INT PRIMARY KEY IDENTITY(1,1),
    BookingId     INT NOT NULL,
    UserId        INT NOT NULL,
    Amount        DECIMAL(10,2) NOT NULL,
    PaymentMethod NVARCHAR(50),
    TransactionNo NVARCHAR(100) UNIQUE,
    Status        NVARCHAR(30)  DEFAULT 'Pending',
    PaymentDate   DATETIME      DEFAULT GETDATE(),

    FOREIGN KEY (BookingId) REFERENCES Bookings(BookingId),
    FOREIGN KEY (UserId)    REFERENCES Users(UserId)
);

INSERT INTO Payments (BookingId, UserId, Amount, PaymentMethod, TransactionNo, Status) VALUES
(1, 5, 3500, 'bKash', 'TXN-BK-001', 'Completed'),
(2, 6, 2500, 'Nagad', 'TXN-NG-002', 'Completed'),
(3, 7, 3000, 'bKash', 'TXN-BK-003', 'Pending');

-- =========================================
-- PREVENT DOUBLE BOOKING (Optional Safety)
-- =========================================

CREATE UNIQUE INDEX UX_ActiveBooking
ON Bookings(SlotId, BookingDate)
WHERE BookingStatus IN ('Pending', 'Confirmed');
GO
